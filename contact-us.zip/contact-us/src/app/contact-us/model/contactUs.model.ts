export class ContactUs{
    name:String;
    email:String;
    rating:String;
    feedback:String;

    constructor(name:String,email:String,rating:String,feedback:String){
       this.name =name ;
       this.email=email;
       this.rating=rating;
       this.feedback=feedback;

    }

}
